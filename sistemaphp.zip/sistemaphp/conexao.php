<?php
	
$servername = "127.0.0.1";
$database = "curso_estoque";
$username = "root";
$password = "";

$conexao = mysqli_connect($servername, $username, $password, $database);	

?>